<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>verif</title>
	
	<!-- Bootstrap CSS -->
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">

	<style type="text/css">
	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
		text-decoration: none;
	}

	a:hover {
		color: #97310e;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
		min-height: 96px;
	}

	p {
		margin: 0 0 10px;
		padding:0;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>

<div id="container ">
	<h1 class="text-primary font-weight-bold">Create</h1>

	<div id="body ">
		<form action="<?php echo base_url('formcontroller/form2'); ?>" method="get">
			<div class="form-group row">
				<label for="nama" class="col-sm-2 col-form-label">Nama:</label>
				<div class="col-sm-10">
					<input type="text" class="form-control" id="nama" name="nama" required>
				</div>
			</div>
			<div class="form-group row">
				<label for="npm" class="col-sm-2 col-form-label">Nomor Pokok Mahasiswa (NPM):</label>
				<div class="col-sm-10">
					<input type="text" class="form-control" id="npm" name="npm" required>
				</div>
			</div>
			<div class="form-group row">
				<label for="jurusan" class="col-sm-2 col-form-label">Jurusan:</label>
				<div class="col-sm-10">
					<input type="text" class="form-control" id="jurusan" name="jurusan" required>
				</div>
			</div>
			<div class="form-group row">
				<label for="prodi" class="col-sm-2 col-form-label">Program Studi (Prodi):</label>
				<div class="col-sm-10">
					<input type="text" class="form-control" id="prodi" name="prodi" required>
				</div>
			</div>
			<div class="form-group row">
				<label for="alamat" class="col-sm-2 col-form-label">Alamat:</label>
				<div class="col-sm-10">
					<input type="text" class="form-control" id="alamat" name="alamat" required>
				</div>
			</div>
			<div class="form-group row">
				<div class="col-sm-10 offset-sm-2">
					<input type="submit" class="btn btn-primary" value="Kirim">
				</div>
			</div>
		</form>

		<body id="page-top"><!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <!-- End of Topbar -->
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Large modal -->
                    <section class="content">
                        <div class="card shadow-sm border-bottom-primary">
                            <!-- Page Heading -->
                            <div class="card-header bg-white py-3">
                                <div class="row">
                                    <div class="col">
                                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                                        Read
                                        </h4>
                                    </div>
                                </div>
                            </div>
                        <br>
                        <br>
                        <?php echo form_open_multipart('formcontroller'); ?>
                        <div class="table-responsive">
                            <table class="table table-striped" id="dataTable" style="color: black;">
                                <thead>
                                    <tr align="center">
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Npm</th>
                                        <th>Jurusan</th>
                                        <th>Prodi</th>
                                        <th>Alamat</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $no = 1; 
                                    if($ambildata) :
                                        foreach ($ambildata->result() as $key): ?>
                                    <tr>
                                        <td ><?php echo $no++ ?></td>
                                        <td><?php echo $key->nama; ?></td>
                                        <td><?php echo $key->npm; ?></td>
                                        <td><?php echo $key->jurusan; ?></td>
                                        <td><?php echo $key->prodi; ?></td>
										<td><?php echo $key->alamat; ?></td>
                                        <td align="center">
                                            <a onclick="return confirm('Yakin ingin menghapus?')" href="<?= base_url('formcontroller/delete/') . $key->id; ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i>hapus</a>
											<a href="<?= base_url('formcontroller/edit/') . $key->id; ?>" class="btn btn-warning btn-circle btn-sm"><i class="fa fa-edit"></i>edit</a>
										</td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php else : ?>
                                    <tr>
                                        <td colspan="9" class="text-center">
                                            Data Kosong
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo form_close() ?>
                    </section>
                </div>
            </div>
        </div>
    </div>
	</div>

	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>

<!-- Bootstrap JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>
