<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Form Failure</title>
	<!-- Bootstrap CSS -->
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
	<h1 class="text-center text-danger">Form Gagal Dikirim</h1>
	<a href="<?php echo base_url('formcontroller/form1'); ?>" class="btn btn-primary">Kembali ke Form</a>
</div>
</body>
</html>
