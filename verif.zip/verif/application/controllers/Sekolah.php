<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sekolah extends CI_Controller {

    public function index()
    {
        // Load form1 view
        $this->load->view('form1');
    }

}
