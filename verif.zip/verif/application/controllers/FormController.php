<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FormController extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_model');
        $this->load->helper('url');
    }

    public function form1()
    {
        $data['ambildata'] = $this->db->get('testing');
        $this->load->view('form1', $data);
        
    }
    public function delete($getId)
    {
        $id = ($getId);
        if ($this->M_model->delete('testing', 'id', $id)) {
            $this->session->set_flashdata('Data berhasil dihapus.');
        } else {
            $this->session->set_flashdata('Data gagal dihapus.', false);
        }
        redirect('formcontroller/form1');
    }

    public function edit($id)
    {
        $data['testing'] = $this->M_model->get_orang_by_id($id);
        $this->load->view('edit', $data);
    }

    public function update($id)
    {
        $data = array(
            'nama' => $this->input->post('nama'),
            'npm' => $this->input->post('npm'),
            'jurusan' => $this->input->post('jurusan'),
            'prodi' => $this->input->post('prodi'),
            'alamat' => $this->input->post('alamat')
        );

        if ($this->M_model->edit($id, $data)) {
            redirect('formcontroller/form1');
        } else {
            $this->load->view('form_failure');
        }
    }

    public function form2()
    {
        
        $data = array(
            'nama' => $this->input->get('nama'),
            'npm' => $this->input->get('npm'),
            'jurusan' => $this->input->get('jurusan'),
            'prodi' => $this->input->get('prodi'),
            'alamat' => $this->input->get('alamat')
        );

        if ($this->M_model->tambah($data)) {
            $this->load->view('form_sukses');
        } else {
            $this->load->view('form_gagal');
        }
        
    }
}
?>
