<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function tambah($data)
    {
        return $this->db->insert('testing', $data);
    }

    public function delete($table, $pk, $id)
    {
        return $this->db->delete($table, [$pk => $id]);
    }

    public function ambil_data($table){
    	return $this->db->get($table);
    }
    public function get_orang_by_id($id)
    {
        return $this->db->get_where('testing', array('id' => $id))->row();
    }

    public function edit($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('testing', $data);
    }

}
?>
